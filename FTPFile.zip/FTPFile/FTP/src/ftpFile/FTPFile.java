package ftpFile;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Scanner;
 
import org.apache.commons.net.ftp.FTP;
import org.apache.commons.net.ftp.FTPClient;
 
public class FTPFile {
    public static void fileUpload(String username,String password,String serveradd, int portno, String uploadFile) throws Exception{
    
        String server = serveradd;
        int port = portno;
        String user = username;
        String pass = password;
 
        FTPClient ftpClient = new FTPClient();
        try {
 
            ftpClient.connect(server, port);
            ftpClient.login(user, pass);
            ftpClient.enterLocalPassiveMode();
 
            ftpClient.setFileType(FTP.BINARY_FILE_TYPE);
 
            // APPROACH #1: uploads first file using an InputStream
            
            // name of the file to you want to upload e.g D:\Downloads\testing.mp4
            File firstLocalFile = new File(uploadFile);
 
            // name of the file to save as
            String firstRemoteFile = "input.mp4";
            InputStream inputStream = new FileInputStream(firstLocalFile);

            System.out.println("Start uploading first file");
            boolean done = ftpClient.storeFile(firstRemoteFile, inputStream);
            inputStream.close();
            if (done) {
                System.out.println("The first file is uploaded successfully.");
            }
            inputStream.close();
 
            boolean completed = ftpClient.completePendingCommand();
            if (completed) {
                System.out.println("The second file is uploaded successfully.");
            }
 
        } catch (IOException ex) {
            System.out.println("Error: " + ex.getMessage());
            ex.printStackTrace();
        } finally {
            if (ftpClient.isConnected()) {
                ftpClient.logout();
                ftpClient.disconnect();
            }
        }    

}
    public static void fileDownload(String username,String password,String serveradd, int portno, String downloadFile) throws Exception{
    
        System.out.println("username : " + username);
        System.out.println("password : " + password);
        String server = serveradd;
        int port = portno;
        String user = username;
        String pass = password;
 
        FTPClient ftpClient = new FTPClient();
        try {
 
            ftpClient.connect(server, port);
            ftpClient.login(user, pass);
            ftpClient.enterLocalPassiveMode();
            ftpClient.setFileType(FTP.BINARY_FILE_TYPE);
            
 /*
            // APPROACH #1: using retrieveFile(String, OutputStream)
            String remoteFile1 = "D:/Downloads/Server/input.mp4";
            File downloadFile1 = new File("D:/Downloads/output.mp4");
            OutputStream outputStream1 = new BufferedOutputStream(new FileOutputStream(downloadFile1));
            boolean success = ftpClient.retrieveFile(remoteFile1, outputStream1);
            outputStream1.close();
 
            if (success) {
                System.out.println("File #1 has been downloaded successfully.");
            }
 */
            // APPROACH #2: using InputStream retrieveFileStream(String)
            String remoteFile2 = "input.mp4";
            File downloadFile2 = new File(downloadFile);
            OutputStream outputStream2 = new BufferedOutputStream(new FileOutputStream(downloadFile2));
            InputStream inputStream = ftpClient.retrieveFileStream(remoteFile2);
            byte[] bytesArray = new byte[4096];
            int bytesRead = -1;
            while ((bytesRead = inputStream.read(bytesArray)) != -1) {
                outputStream2.write(bytesArray, 0, bytesRead);
            }
            boolean success = ftpClient.retrieveFile(remoteFile2, outputStream2);
            success = ftpClient.completePendingCommand();
            if (success) {
                System.out.println("File #2 has been downloaded successfully.");
            }
            outputStream2.close();
            inputStream.close();
 
        } catch (IOException ex) {
            System.out.println("Error: " + ex.getMessage());
            ex.printStackTrace();
        } finally {
            try {
                if (ftpClient.isConnected()) {
                    ftpClient.logout();
                    ftpClient.disconnect();
                }
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }
    }
    public static void main(String[] args) throws Exception{
        Scanner sc = new Scanner(System.in);
    
        System.out.println("Please enter username");
        String username = sc.nextLine();
        System.out.println("Please enter password");
        String password = sc.nextLine();
       // System.out.println("Please enter server ip address");
        //String serveradd = sc.nextLine();
        String serveradd = "localhost";
        //System.out.println("Please enter portno");
        //int portno = sc.nextInt();
        int portno = 21;
        
        // name of the file to you want to upload e.g D:\Downloads\testing.mp4
        System.out.println("Please enter name of file to upload");
        String uploadFile = sc.nextLine();
        // name of the file to you want to download e.g D:\Downloads\input.mp4
        System.out.println("Please enter name of file to download");
        String downloadFile = sc.nextLine();
        
        System.out.println("Please enter choice, 1 to upload and 2 to download");
        int i = 0;
        while(i == 0)
        {
        int choice = sc.nextInt();
        if(choice == 1)
            {
                //this will upload a file to the server location u set on fileZilla
            fileUpload(username,password,serveradd,portno,uploadFile);
            }
        else if (choice == 2)
            {
                //this will download a file to the server location you entered
        fileDownload(username,password,serveradd,portno,downloadFile);
            }
        else
        {
            i = 2;
        }
        }
    }
}